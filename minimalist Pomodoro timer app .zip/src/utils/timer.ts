import { useState, useEffect, useCallback } from "react";

export function useTimer() {
  const [focusMinutes, setFocusMinutesState] = useState(() => {
    const saved = localStorage.getItem("pomodoro-focus");
    return saved ? parseInt(saved, 10) : 25;
  });

  const [breakMinutes, setBreakMinutesState] = useState(() => {
    const saved = localStorage.getItem("pomodoro-break");
    return saved ? parseInt(saved, 10) : 5;
  });

  const [isFocusMode, setIsFocusMode] = useState(true);
  const [isRunning, setIsRunning] = useState(false);
  const [timeLeft, setTimeLeft] = useState(focusMinutes * 60);

  // Save to localStorage when settings change
  useEffect(() => {
    localStorage.setItem("pomodoro-focus", focusMinutes.toString());
  }, [focusMinutes]);

  useEffect(() => {
    localStorage.setItem("pomodoro-break", breakMinutes.toString());
  }, [breakMinutes]);

  // Reset timer when mode or duration changes
  useEffect(() => {
    if (!isRunning) {
      setTimeLeft(isFocusMode ? focusMinutes * 60 : breakMinutes * 60);
    }
  }, [focusMinutes, breakMinutes, isFocusMode, isRunning]);

  // Timer countdown
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isRunning) {
      setIsRunning(false);
      // Auto-switch mode after completion
      setTimeout(() => {
        setIsFocusMode((prev) => !prev);
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, timeLeft]);

  const toggleTimer = useCallback(() => {
    setIsRunning((prev) => !prev);
  }, []);

  const resetTimer = useCallback(() => {
    setIsRunning(false);
    setTimeLeft(isFocusMode ? focusMinutes * 60 : breakMinutes * 60);
  }, [isFocusMode, focusMinutes, breakMinutes]);

  const switchMode = useCallback(() => {
    setIsRunning(false);
    setIsFocusMode((prev) => !prev);
  }, []);

  const setFocusMinutes = useCallback((minutes: number) => {
    setFocusMinutesState(minutes);
  }, []);

  const setBreakMinutes = useCallback((minutes: number) => {
    setBreakMinutesState(minutes);
  }, []);

  return {
    timeLeft,
    isRunning,
    isFocusMode,
    focusMinutes,
    breakMinutes,
    toggleTimer,
    resetTimer,
    setFocusMinutes,
    setBreakMinutes,
    switchMode,
  };
}