import { useState, useEffect, useRef } from "react";
import { Button } from "../components/ui/button";

interface AudioAlertProps {
  timeLeft: number;
}

export function AudioAlert({ timeLeft }: AudioAlertProps) {
  const [isMuted, setIsMuted] = useState(() => {
    const saved = localStorage.getItem("pomodoro-muted");
    return saved === "true";
  });
  const hasPlayedRef = useRef(false);

  useEffect(() => {
    localStorage.setItem("pomodoro-muted", isMuted.toString());
  }, [isMuted]);

  useEffect(() => {
    if (timeLeft === 0 && !isMuted && !hasPlayedRef.current) {
      playBeep();
      hasPlayedRef.current = true;
    }
    if (timeLeft > 0) {
      hasPlayedRef.current = false;
    }
  }, [timeLeft, isMuted]);

  const playBeep = () => {
    try {
      const audioContext = new (window.AudioContext ||
        (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.value = 800;
      oscillator.type = "sine";

      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(
        0.01,
        audioContext.currentTime + 0.5
      );

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.5);
    } catch (error) {
      console.error("Audio playback failed:", error);
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  return (
    <div className="flex justify-center mt-6">
      <Button
        variant="ghost"
        size="icon"
        onClick={toggleMute}
        className="text-slate-400 hover:text-slate-100 hover:bg-slate-800"
        aria-label={isMuted ? "Unmute" : "Mute"}
      >
        {isMuted ? (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-5 h-5"
          >
            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
            <line x1="23" y1="9" x2="17" y2="15" />
            <line x1="17" y1="9" x2="23" y2="15" />
          </svg>
        ) : (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-5 h-5"
          >
            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
            <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07" />
          </svg>
        )}
      </Button>
    </div>
  );
}