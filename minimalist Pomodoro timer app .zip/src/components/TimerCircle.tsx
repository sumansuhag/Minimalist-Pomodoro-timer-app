import { useEffect, useState } from "react";

interface TimerCircleProps {
  timeLeft: number;
  totalTime: number;
  progress: number;
  isFocusMode: boolean;
  isLastTenSeconds: boolean;
}

export function TimerCircle({
  timeLeft,
  totalTime,
  progress,
  isFocusMode,
  isLastTenSeconds,
}: TimerCircleProps) {
  const [displayTime, setDisplayTime] = useState(timeLeft);

  useEffect(() => {
    setDisplayTime(timeLeft);
  }, [timeLeft]);

  const minutes = Math.floor(displayTime / 60);
  const seconds = displayTime % 60;
  const formattedTime = `${minutes.toString().padStart(2, "0")}:${seconds
    .toString()
    .padStart(2, "0")}`;

  const circumference = 2 * Math.PI * 120;
  const offset = circumference - (progress / 100) * circumference;

  const getColorClasses = () => {
    if (isLastTenSeconds) {
      return {
        stroke: "stroke-red-500",
        text: "text-red-500",
      };
    }
    if (isFocusMode) {
      return {
        stroke: "stroke-emerald-500",
        text: "text-emerald-500",
      };
    }
    return {
      stroke: "stroke-amber-500",
      text: "text-amber-500",
    };
  };

  const colors = getColorClasses();

  return (
    <div className="relative flex items-center justify-center">
      <svg className="w-72 h-72 transform -rotate-90" viewBox="0 0 280 280">
        {/* Background circle */}
        <circle
          cx="140"
          cy="140"
          r="120"
          stroke="currentColor"
          strokeWidth="8"
          fill="none"
          className="text-slate-700"
        />
        {/* Progress circle */}
        <circle
          cx="140"
          cy="140"
          r="120"
          stroke="currentColor"
          strokeWidth="8"
          fill="none"
          strokeLinecap="round"
          className={`${colors.stroke} transition-all duration-300 ease-in-out`}
          style={{
            strokeDasharray: circumference,
            strokeDashoffset: offset,
          }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span
          className={`text-6xl font-bold tabular-nums ${colors.text} transition-colors duration-300`}
        >
          {formattedTime}
        </span>
      </div>
    </div>
  );
}