import { Button } from "../components/ui/button";

interface SettingsPanelProps {
  focusMinutes: number;
  breakMinutes: number;
  onFocusChange: (minutes: number) => void;
  onBreakChange: (minutes: number) => void;
}

export function SettingsPanel({
  focusMinutes,
  breakMinutes,
  onFocusChange,
  onBreakChange,
}: SettingsPanelProps) {
  const adjustTime = (
    current: number,
    onChange: (minutes: number) => void,
    delta: number
  ) => {
    const newValue = Math.max(1, Math.min(60, current + delta));
    onChange(newValue);
  };

  return (
    <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
      <h2 className="text-lg font-medium mb-4 text-slate-200">Timer Settings</h2>

      <div className="space-y-6">
        {/* Focus Time */}
        <div className="flex items-center justify-between">
          <div>
            <label className="text-sm text-slate-400 block mb-1">
              Focus Duration
            </label>
            <span className="text-2xl font-semibold text-slate-100">
              {focusMinutes} min
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => adjustTime(focusMinutes, onFocusChange, -5)}
              className="h-10 w-10 rounded-lg border-slate-600 hover:bg-slate-700"
              disabled={focusMinutes <= 1}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="w-4 h-4"
              >
                <line x1="5" y1="12" x2="19" y2="12" />
              </svg>
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => adjustTime(focusMinutes, onFocusChange, 5)}
              className="h-10 w-10 rounded-lg border-slate-600 hover:bg-slate-700"
              disabled={focusMinutes >= 60}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="w-4 h-4"
              >
                <line x1="12" y1="5" x2="12" y2="19" />
                <line x1="5" y1="12" x2="19" y2="12" />
              </svg>
            </Button>
          </div>
        </div>

        {/* Break Time */}
        <div className="flex items-center justify-between">
          <div>
            <label className="text-sm text-slate-400 block mb-1">
              Break Duration
            </label>
            <span className="text-2xl font-semibold text-slate-100">
              {breakMinutes} min
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => adjustTime(breakMinutes, onBreakChange, -1)}
              className="h-10 w-10 rounded-lg border-slate-600 hover:bg-slate-700"
              disabled={breakMinutes <= 1}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="w-4 h-4"
              >
                <line x1="5" y1="12" x2="19" y2="12" />
              </svg>
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => adjustTime(breakMinutes, onBreakChange, 1)}
              className="h-10 w-10 rounded-lg border-slate-600 hover:bg-slate-700"
              disabled={breakMinutes >= 60}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="w-4 h-4"
              >
                <line x1="12" y1="5" x2="12" y2="19" />
                <line x1="5" y1="12" x2="19" y2="12" />
              </svg>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}